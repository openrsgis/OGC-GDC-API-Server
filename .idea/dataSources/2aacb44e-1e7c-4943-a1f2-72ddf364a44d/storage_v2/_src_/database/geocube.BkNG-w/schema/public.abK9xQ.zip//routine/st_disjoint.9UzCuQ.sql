create function st_disjoint(rast1 raster, nband1 integer, rast2 raster, nband2 integer) returns boolean
    immutable
    cost 1000
    language sql
as
$$
SELECT CASE WHEN $2 IS NULL OR $4 IS NULL THEN st_disjoint(st_convexhull($1), st_convexhull($3)) ELSE NOT _st_intersects($1, $2, $3, $4) END
$$;

comment on function st_disjoint(raster, integer, raster, integer) is 'args: rastA, nbandA, rastB, nbandB - Return true if raster rastA does not spatially intersect rastB.';

alter function st_disjoint(raster, integer, raster, integer) owner to postgres;

