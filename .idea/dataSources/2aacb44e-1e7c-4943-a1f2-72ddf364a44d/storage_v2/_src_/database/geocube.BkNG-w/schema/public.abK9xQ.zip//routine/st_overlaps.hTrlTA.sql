create function st_overlaps(rast1 raster, rast2 raster) returns boolean
    immutable
    cost 1000
    language sql
as
$$
SELECT st_overlaps($1, NULL::integer, $2, NULL::integer)
$$;

comment on function st_overlaps(raster, raster) is 'args: rastA, rastB - Return true if raster rastA and rastB intersect but one does not completely contain the other.';

alter function st_overlaps(raster, raster) owner to postgres;

