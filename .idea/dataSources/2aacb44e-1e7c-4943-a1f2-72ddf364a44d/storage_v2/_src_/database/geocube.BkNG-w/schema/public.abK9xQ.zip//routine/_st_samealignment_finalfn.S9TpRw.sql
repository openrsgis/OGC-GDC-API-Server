create function _st_samealignment_finalfn(agg agg_samealignment) returns boolean
    immutable
    strict
    language sql
as
$$
SELECT $1.aligned
$$;

alter function _st_samealignment_finalfn(agg_samealignment) owner to postgres;

