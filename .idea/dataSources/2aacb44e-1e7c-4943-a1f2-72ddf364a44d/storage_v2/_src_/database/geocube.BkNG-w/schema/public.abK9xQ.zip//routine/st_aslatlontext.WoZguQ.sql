create function st_aslatlontext(geometry) returns text
    immutable
    strict
    language sql
as
$$
SELECT ST_AsLatLonText($1, '')
$$;

comment on function st_aslatlontext(geometry) is 'args: pt - Return the Degrees, Minutes, Seconds representation of the given point.';

alter function st_aslatlontext(geometry) owner to postgres;

