create function st_rotate(geometry, double precision, geometry) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_Affine($1,  cos($2), -sin($2), 0,  sin($2),  cos($2), 0, 0, 0, 1, ST_X($3) - cos($2) * ST_X($3) + sin($2) * ST_Y($3), ST_Y($3) - sin($2) * ST_X($3) - cos($2) * ST_Y($3), 0)
$$;

comment on function st_rotate(geometry, double precision, geometry) is 'args: geomA, rotRadians, pointOrigin - Rotate a geometry rotRadians counter-clockwise about an origin.';

alter function st_rotate(geometry, double precision, geometry) owner to postgres;

