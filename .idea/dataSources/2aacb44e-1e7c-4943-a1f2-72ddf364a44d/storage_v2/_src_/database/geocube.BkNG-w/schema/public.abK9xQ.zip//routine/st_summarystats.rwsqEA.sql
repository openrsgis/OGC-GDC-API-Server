create function st_summarystats(rast raster, exclude_nodata_value boolean, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision) returns record
    immutable
    strict
    language sql
as
$$
SELECT _st_summarystats($1, 1, $2, 1)
$$;

comment on function st_summarystats(raster, boolean, out bigint, out double precision, out double precision, out double precision, out double precision, out double precision) is 'args: rast, exclude_nodata_value - Returns record consisting of count, sum, mean, stddev, min, max for a given raster band of a raster or raster coverage. Band 1 is assumed is no band is specified.';

alter function st_summarystats(raster, boolean, out bigint, out double precision, out double precision, out double precision, out double precision, out double precision) owner to postgres;

