create function st_dfullywithin(rast1 raster, rast2 raster, distance double precision) returns boolean
    immutable
    cost 1000
    language sql
as
$$
SELECT st_dfullywithin($1, NULL::integer, $2, NULL::integer, $3)
$$;

comment on function st_dfullywithin(raster, raster, double precision) is 'args: rastA, rastB, distance_of_srid - Return true if rasters rastA and rastB are fully within the specified distance of each other.';

alter function st_dfullywithin(raster, raster, double precision) owner to postgres;

