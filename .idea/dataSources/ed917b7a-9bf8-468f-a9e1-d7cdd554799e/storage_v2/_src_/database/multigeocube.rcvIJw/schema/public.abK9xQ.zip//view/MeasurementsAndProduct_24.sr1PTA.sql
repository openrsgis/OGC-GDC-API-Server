create view "MeasurementsAndProduct_24"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_24.dtype,
       gc_product_24.product_key,
       gc_product_24.product_name
FROM gc_measurement
         JOIN gc_product_measurement_24 ON gc_product_measurement_24.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_24 ON gc_product_measurement_24.product_key = gc_product_24.product_key;

alter table "MeasurementsAndProduct_24"
    owner to geocube;

