create view "MeasurementsAndProduct_12"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_12.dtype,
       gc_product_12.product_key,
       gc_product_12.product_name
FROM gc_measurement
         JOIN gc_product_measurement_12 ON gc_product_measurement_12.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_12 ON gc_product_measurement_12.product_key = gc_product_12.product_key;

alter table "MeasurementsAndProduct_12"
    owner to geocube;

