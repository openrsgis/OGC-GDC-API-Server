create view "LevelAndExtent_18"
            (extent_key, grid_code, city_code, province_name, district_name, extent, tile_size, cell_res, level) as
SELECT gc_extent_18.extent_key,
       gc_extent_18.grid_code,
       gc_extent_18.city_code,
       gc_extent_18.province_name,
       gc_extent_18.district_name,
       gc_extent_18.extent,
       gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level
FROM gc_extent_18
         JOIN gc_level ON gc_extent_18.resolution_key = gc_level.resolution_key;

alter table "LevelAndExtent_18"
    owner to geocube;

