create view "MeasurementsAndProduct_26"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_26.dtype,
       gc_product_26.product_key,
       gc_product_26.product_name
FROM gc_measurement
         JOIN gc_product_measurement_26 ON gc_product_measurement_26.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_26 ON gc_product_measurement_26.product_key = gc_product_26.product_key;

alter table "MeasurementsAndProduct_26"
    owner to geocube;

