create function st_summarystats(rastertable text, rastercolumn text, exclude_nodata_value boolean, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision) returns record
    stable
    strict
    language sql
as
$$
SELECT _st_summarystats($1, $2, 1, $3, 1)
$$;

comment on function st_summarystats(text, text, boolean, out bigint, out double precision, out double precision, out double precision, out double precision, out double precision) is 'args: rastertable, rastercolumn, exclude_nodata_value - Returns record consisting of count, sum, mean, stddev, min, max for a given raster band of a raster or raster coverage. Band 1 is assumed is no band is specified.';

alter function st_summarystats(text, text, boolean, out bigint, out double precision, out double precision, out double precision, out double precision, out double precision) owner to postgres;

