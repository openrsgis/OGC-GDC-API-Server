create function st_asgml(text) returns text
    immutable
    strict
    language sql
as
$$
SELECT _ST_AsGML(2,$1::geometry,15,0, NULL, NULL);
$$;

alter function st_asgml(text) owner to postgres;

