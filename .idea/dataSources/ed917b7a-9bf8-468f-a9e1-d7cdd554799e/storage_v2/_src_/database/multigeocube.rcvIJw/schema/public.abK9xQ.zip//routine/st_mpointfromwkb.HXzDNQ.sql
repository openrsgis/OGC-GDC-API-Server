create function st_mpointfromwkb(bytea, integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1, $2)) = 'MULTIPOINT'
	THEN ST_GeomFromWKB($1, $2)
	ELSE NULL END

$$;

alter function st_mpointfromwkb(bytea, integer) owner to postgres;

