create view "MeasurementsAndProduct_7"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_7.dtype,
       gc_product_7.product_key,
       gc_product_7.product_name
FROM gc_measurement
         JOIN gc_product_measurement_7 ON gc_product_measurement_7.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_7 ON gc_product_measurement_7.product_key = gc_product_7.product_key;

alter table "MeasurementsAndProduct_7"
    owner to geocube;

