create view "MeasurementsAndProduct_25"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_25.dtype,
       gc_product_25.product_key,
       gc_product_25.product_name
FROM gc_measurement
         JOIN gc_product_measurement_25 ON gc_product_measurement_25.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_25 ON gc_product_measurement_25.product_key = gc_product_25.product_key;

alter table "MeasurementsAndProduct_25"
    owner to geocube;

