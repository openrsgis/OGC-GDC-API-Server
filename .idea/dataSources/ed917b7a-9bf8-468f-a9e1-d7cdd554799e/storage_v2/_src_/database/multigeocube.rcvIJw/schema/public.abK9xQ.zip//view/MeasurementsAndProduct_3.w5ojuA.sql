create view "MeasurementsAndProduct_3"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_3.dtype,
       gc_product_3.product_key,
       gc_product_3.product_name
FROM gc_measurement
         JOIN gc_product_measurement_3 ON gc_product_measurement_3.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_3 ON gc_product_measurement_3.product_key = gc_product_3.product_key;

alter table "MeasurementsAndProduct_3"
    owner to geocube;

