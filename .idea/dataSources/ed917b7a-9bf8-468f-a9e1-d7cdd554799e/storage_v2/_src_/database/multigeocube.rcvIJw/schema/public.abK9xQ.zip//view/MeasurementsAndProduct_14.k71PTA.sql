create view "MeasurementsAndProduct_14"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_14.dtype,
       gc_product_14.product_key,
       gc_product_14.product_name
FROM gc_measurement
         JOIN gc_product_measurement_14 ON gc_product_measurement_14.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_14 ON gc_product_measurement_14.product_key = gc_product_14.product_key;

alter table "MeasurementsAndProduct_14"
    owner to geocube;

