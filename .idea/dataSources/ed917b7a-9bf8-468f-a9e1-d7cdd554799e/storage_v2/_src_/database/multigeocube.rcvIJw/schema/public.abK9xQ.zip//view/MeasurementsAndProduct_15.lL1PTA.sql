create view "MeasurementsAndProduct_15"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_15.dtype,
       gc_product_15.product_key,
       gc_product_15.product_name
FROM gc_measurement
         JOIN gc_product_measurement_15 ON gc_product_measurement_15.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_15 ON gc_product_measurement_15.product_key = gc_product_15.product_key;

alter table "MeasurementsAndProduct_15"
    owner to geocube;

