create view "LevelAndExtent_24"
            (extent_key, grid_code, city_code, province_name, district_name, extent, tile_size, cell_res, level) as
SELECT gc_extent_24.extent_key,
       gc_extent_24.grid_code,
       gc_extent_24.city_code,
       gc_extent_24.province_name,
       gc_extent_24.district_name,
       gc_extent_24.extent,
       gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level
FROM gc_extent_24
         JOIN gc_level ON gc_extent_24.resolution_key = gc_level.resolution_key;

alter table "LevelAndExtent_24"
    owner to geocube;

