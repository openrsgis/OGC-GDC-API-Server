create function st_distance_sphere(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    cost 300
    language sql
as
$$
select st_distance(geography($1),geography($2),false)

$$;

comment on function st_distance_sphere(geometry, geometry) is 'args: geomlonlatA, geomlonlatB - Returns minimum distance in meters between two lon/lat geometries. Uses a spherical earth and radius of 6370986 meters. Faster than ST_Distance_Spheroid , but less accurate. PostGIS versions prior to 1.5 only implemented for points.';

alter function st_distance_sphere(geometry, geometry) owner to postgres;

