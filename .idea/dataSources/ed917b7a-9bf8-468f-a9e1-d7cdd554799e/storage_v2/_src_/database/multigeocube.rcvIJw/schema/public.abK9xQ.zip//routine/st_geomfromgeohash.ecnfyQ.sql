create function st_geomfromgeohash(text, integer DEFAULT NULL::integer) returns geometry
    immutable
    language sql
as
$$
SELECT CAST(ST_Box2dFromGeoHash($1, $2) AS geometry);
$$;

comment on function st_geomfromgeohash(text, integer) is 'args: geohash, precision=full_precision_of_geohash - Return a geometry from a GeoHash string.';

alter function st_geomfromgeohash(text, integer) owner to postgres;

