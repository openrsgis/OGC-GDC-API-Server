create view "LevelAndExtent_21"
            (extent_key, grid_code, city_code, province_name, district_name, extent, tile_size, cell_res, level) as
SELECT gc_extent_21.extent_key,
       gc_extent_21.grid_code,
       gc_extent_21.city_code,
       gc_extent_21.province_name,
       gc_extent_21.district_name,
       gc_extent_21.extent,
       gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level
FROM gc_extent_21
         JOIN gc_level ON gc_extent_21.resolution_key = gc_level.resolution_key;

alter table "LevelAndExtent_21"
    owner to geocube;

