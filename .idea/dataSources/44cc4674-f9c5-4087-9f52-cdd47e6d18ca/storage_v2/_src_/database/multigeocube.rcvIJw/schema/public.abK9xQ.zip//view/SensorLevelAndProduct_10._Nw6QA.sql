create view "SensorLevelAndProduct_10"
            (tile_size, cell_res, level, product_key, product_name, product_type, crs, phenomenon_time, result_time,
             geom, upper_left_lat, upper_left_long, upper_right_lat, upper_right_long, lower_left_lat, lower_left_long,
             lower_right_lat, lower_right_long, sensor_name, platform_name, imaging_length, imaging_width,
             phenomenon_time_month, phenomenon_time_year)
as
SELECT gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level,
       gc_product_10.product_key,
       gc_product_10.product_name,
       gc_product_10.product_type,
       gc_product_10.crs,
       gc_product_10.phenomenon_time,
       gc_product_10.result_time,
       gc_product_10.geom,
       gc_product_10.upper_left_lat,
       gc_product_10.upper_left_long,
       gc_product_10.upper_right_lat,
       gc_product_10.upper_right_long,
       gc_product_10.lower_left_lat,
       gc_product_10.lower_left_long,
       gc_product_10.lower_right_lat,
       gc_product_10.lower_right_long,
       gc_sensor.sensor_name,
       gc_sensor.platform_name,
       gc_sensor.imaging_length,
       gc_sensor.imaging_width,
       gc_product_10.phenomenon_time_month,
       gc_product_10.phenomenon_time_year
FROM gc_level
         JOIN gc_product_10 ON gc_product_10.resolution_key = gc_level.resolution_key
         JOIN gc_sensor ON gc_product_10.sensor_key = gc_sensor.sensor_key;

alter table "SensorLevelAndProduct_10"
    owner to geocube;

