create function st_approxquantile(rastertable text, rastercolumn text, quantiles double precision[]) returns SETOF quantile
    stable
    strict
    language sql
as
$$
SELECT _st_quantile($1, $2, 1, TRUE, 0.1, $3)
$$;

alter function st_approxquantile(text, text, double precision[]) owner to postgres;

