create function _st_mapalgebra4unionstate(rast1 raster, rast2 raster, bandnum integer) returns raster
    language sql
as
$$
SELECT _ST_MapAlgebra4UnionState($1,ST_Band($2,$3), 'LAST', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
$$;

alter function _st_mapalgebra4unionstate(raster, raster, integer) owner to postgres;

