create function st_approxquantile(rast raster, quantiles double precision[]) returns SETOF quantile
    immutable
    strict
    language sql
as
$$
SELECT _st_quantile($1, 1, TRUE, 0.1, $2)
$$;

alter function st_approxquantile(raster, double precision[]) owner to postgres;

