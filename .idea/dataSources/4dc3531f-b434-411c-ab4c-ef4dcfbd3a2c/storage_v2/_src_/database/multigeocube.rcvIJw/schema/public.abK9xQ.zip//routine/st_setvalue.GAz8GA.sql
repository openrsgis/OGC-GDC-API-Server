create function st_setvalue(rast raster, band integer, pt geometry, newvalue double precision) returns raster
    immutable
    language plpgsql
as
$$
DECLARE
        x float8;
        y float8;
        gtype text;
    BEGIN
        gtype := st_geometrytype(pt);
        IF ( gtype != 'ST_Point' ) THEN
            RAISE EXCEPTION 'Attempting to get the value of a pixel with a non-point geometry';
        END IF;

        IF st_srid(pt) != st_srid(rast) THEN
            RAISE NOTICE 'The SRIDs of the raster and point geometry do NOT match. Returning original raster';
            RETURN rast;
        END IF;

        x := st_x(pt);
        y := st_y(pt);

        RETURN st_setvalue(rast,
                           band,
                           st_world2rastercoordx(rast, x, y),
                           st_world2rastercoordy(rast, x, y),
                           newvalue);
    END;
$$;

comment on function st_setvalue(raster, integer, geometry, double precision) is 'args: rast, bandnum, pt, newvalue - Returns modified raster resulting from setting the value of a given band in a given columnx, rowy pixel or at a pixel that intersects a particular geometric point. Band numbers start at 1 and assumed to be 1 if not specified.';

alter function st_setvalue(raster, integer, geometry, double precision) owner to postgres;

