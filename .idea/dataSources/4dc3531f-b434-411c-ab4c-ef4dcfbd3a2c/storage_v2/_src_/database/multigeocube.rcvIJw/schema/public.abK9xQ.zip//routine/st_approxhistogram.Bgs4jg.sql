create function st_approxhistogram(rast raster, nband integer, sample_percent double precision, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false) returns SETOF histogram
    immutable
    strict
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, $2, TRUE, $3, $4, $5, $6)
$$;

alter function st_approxhistogram(raster, integer, double precision, integer, double precision[], boolean) owner to postgres;

