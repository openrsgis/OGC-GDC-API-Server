create view "LevelAndExtent"
            (extent_key, grid_code, city_code, city_name, province_name, province_code, district_name, extent,
             tile_size, cell_res, level)
as
SELECT gc_tms_extent.extent_key,
       gc_tms_extent.grid_code,
       gc_tms_extent.city_code,
       gc_tms_extent.city_name,
       gc_tms_extent.province_name,
       gc_tms_extent.province_code,
       gc_tms_extent.district_name,
       gc_tms_extent.extent,
       gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level
FROM gc_level
         JOIN gc_tms_extent ON gc_tms_extent.resolution_key = gc_level.resolution_key;

alter table "LevelAndExtent"
    owner to geocube;

