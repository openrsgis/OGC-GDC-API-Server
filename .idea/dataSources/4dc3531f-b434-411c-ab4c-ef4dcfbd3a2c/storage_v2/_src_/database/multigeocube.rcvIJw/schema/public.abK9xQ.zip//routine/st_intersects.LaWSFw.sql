create function st_intersects(rast1 raster, rast2 raster) returns boolean
    immutable
    cost 1000
    language sql
as
$$
SELECT st_intersects($1, NULL::integer, $2, NULL::integer)
$$;

comment on function st_intersects(raster, raster) is 'args: rasta, rastb - Return true if the raster spatially intersects a separate raster or geometry. If the band number is not provided (or set to NULL), only the convex hull of the raster is considered in the test. If the band number is provided, only those pixels with value (not NODATA) are considered in the test.';

alter function st_intersects(raster, raster) owner to postgres;

