create function st_envelope(raster) returns geometry
    immutable
    strict
    language sql
as
$$
select st_envelope(st_convexhull($1))
$$;

comment on function st_envelope(raster) is 'args: rast - Returns the polygon representation of the extent of the raster.';

alter function st_envelope(raster) owner to postgres;

