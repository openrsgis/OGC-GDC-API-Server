create function st_intersects(geom geometry, rast raster, nband integer DEFAULT NULL::integer) returns boolean
    immutable
    cost 1000
    language sql
as
$$
SELECT $1 && $2::geometry AND _st_intersects($1, $2, $3);
$$;

comment on function st_intersects(geometry, raster, integer) is 'args: geommin, rast, nband=NULL - Return true if the raster spatially intersects a separate raster or geometry. If the band number is not provided (or set to NULL), only the convex hull of the raster is considered in the test. If the band number is provided, only those pixels with value (not NODATA) are considered in the test.';

alter function st_intersects(geometry, raster, integer) owner to postgres;

