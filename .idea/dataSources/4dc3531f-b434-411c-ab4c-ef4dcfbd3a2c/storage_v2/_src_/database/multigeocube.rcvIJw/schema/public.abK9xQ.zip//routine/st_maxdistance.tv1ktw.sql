create function st_maxdistance(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT _ST_MaxDistance(ST_ConvexHull($1), ST_ConvexHull($2))
$$;

comment on function st_maxdistance(geometry, geometry) is 'args: g1, g2 - Returns the 2-dimensional largest distance between two geometries in projected units.';

alter function st_maxdistance(geometry, geometry) owner to postgres;

