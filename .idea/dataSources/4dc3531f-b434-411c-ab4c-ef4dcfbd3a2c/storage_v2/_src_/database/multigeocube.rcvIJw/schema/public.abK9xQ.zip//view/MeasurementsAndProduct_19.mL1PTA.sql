create view "MeasurementsAndProduct_19"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_19.dtype,
       gc_product_19.product_key,
       gc_product_19.product_name
FROM gc_measurement
         JOIN gc_product_measurement_19 ON gc_product_measurement_19.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_19 ON gc_product_measurement_19.product_key = gc_product_19.product_key;

alter table "MeasurementsAndProduct_19"
    owner to geocube;

