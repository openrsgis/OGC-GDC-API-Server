create function postgis_raster_scripts_installed() returns text
    immutable
    language sql
as
$$
SELECT '2.0.7'::text || ' r' || 13406::text AS version
$$;

alter function postgis_raster_scripts_installed() owner to postgres;

