create function st_histogram(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, bins integer DEFAULT 0, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false) returns SETOF histogram
    immutable
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, $2, $3, 1, $4, $5, $6)
$$;

comment on function st_histogram(raster, integer, boolean, integer, double precision[], boolean) is 'args: rast, nband=1, exclude_nodata_value=true, bins=autocomputed, width=NULL, right=false - Returns a set of histogram summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(raster, integer, boolean, integer, double precision[], boolean) owner to postgres;

