create function st_pixelaspolygons(rast raster, band integer DEFAULT 1, OUT geom geometry, OUT val double precision, OUT x integer, OUT y integer) returns SETOF record
    language plpgsql
as
$$
DECLARE
        rast alias for $1;
        var_w integer;
        var_h integer;
        var_x integer;
        var_y integer;
        value float8 := NULL;
        hasband boolean := TRUE;
    BEGIN
        IF rast IS NOT NULL AND NOT ST_IsEmpty(rast) THEN
            IF ST_HasNoBand(rast, band) THEN
                RAISE NOTICE 'Raster do not have band %. Returning null values', band;
                hasband := false;
            END IF;
            SELECT ST_Width(rast), ST_Height(rast) INTO var_w, var_h;
            FOR var_x IN 1..var_w LOOP
                FOR var_y IN 1..var_h LOOP
                    IF hasband THEN
                        value := ST_Value(rast, band, var_x, var_y);
                    END IF;
                    SELECT ST_PixelAsPolygon(rast, var_x, var_y), value, var_x, var_y INTO geom,val,x,y;
                    RETURN NEXT;
                END LOOP;
            END LOOP;
        END IF;
        RETURN;
    END;
$$;

comment on function st_pixelaspolygons(raster, integer, out geometry, out double precision, out integer, out integer) is 'args: rast, band=1 - Returns the geometry that bounds every pixel of a raster band along with the value, the X and the Y raster coordinates of each pixel.';

alter function st_pixelaspolygons(raster, integer, out geometry, out double precision, out integer, out integer) owner to postgres;

