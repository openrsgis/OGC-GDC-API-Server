create function st_clip(rast raster, band integer, geom geometry, crop boolean) returns raster
    stable
    language sql
as
$$
SELECT ST_Clip($1, $2, $3, null::float8[], $4)
$$;

comment on function st_clip(raster, integer, geometry, boolean) is 'args: rast, band, geom, crop - Returns the raster clipped by the input geometry. If no band is specified all bands are returned. If crop is not specified, true is assumed meaning the output raster is cropped.';

alter function st_clip(raster, integer, geometry, boolean) owner to postgres;

