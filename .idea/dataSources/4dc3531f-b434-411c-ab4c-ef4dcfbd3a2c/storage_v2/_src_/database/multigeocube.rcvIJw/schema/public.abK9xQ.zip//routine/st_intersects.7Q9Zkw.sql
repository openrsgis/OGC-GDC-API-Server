create function st_intersects(rast1 raster, nband1 integer, rast2 raster, nband2 integer) returns boolean
    immutable
    cost 1000
    language sql
as
$$
SELECT $1 && $3 AND CASE WHEN $2 IS NULL OR $4 IS NULL THEN TRUE ELSE _st_intersects($1, $2, $3, $4) END
$$;

comment on function st_intersects(raster, integer, raster, integer) is 'args: rasta, nbanda, rastb, nbandb - Return true if the raster spatially intersects a separate raster or geometry. If the band number is not provided (or set to NULL), only the convex hull of the raster is considered in the test. If the band number is provided, only those pixels with value (not NODATA) are considered in the test.';

alter function st_intersects(raster, integer, raster, integer) owner to postgres;

