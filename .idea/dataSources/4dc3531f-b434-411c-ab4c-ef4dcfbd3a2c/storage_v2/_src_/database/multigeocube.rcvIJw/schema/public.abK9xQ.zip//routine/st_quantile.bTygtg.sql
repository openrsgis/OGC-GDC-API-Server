create function st_quantile(rastertable text, rastercolumn text, quantiles double precision[]) returns SETOF quantile
    stable
    strict
    language sql
as
$$
SELECT _st_quantile($1, $2, 1, TRUE, 1, $3)
$$;

alter function st_quantile(text, text, double precision[]) owner to postgres;

