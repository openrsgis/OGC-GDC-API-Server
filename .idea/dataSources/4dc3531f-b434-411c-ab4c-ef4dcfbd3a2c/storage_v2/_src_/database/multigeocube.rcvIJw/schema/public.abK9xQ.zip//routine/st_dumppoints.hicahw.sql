create function st_dumppoints(geometry) returns SETOF geometry_dump
    strict
    language sql
as
$$
SELECT * FROM _ST_DumpPoints($1, NULL);
$$;

comment on function st_dumppoints(geometry) is 'args: geom - Returns a set of geometry_dump (geom,path) rows of all points that make up a geometry.';

alter function st_dumppoints(geometry) owner to postgres;

