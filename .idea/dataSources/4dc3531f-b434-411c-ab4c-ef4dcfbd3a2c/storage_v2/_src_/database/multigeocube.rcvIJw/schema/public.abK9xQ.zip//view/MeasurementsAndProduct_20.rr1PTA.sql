create view "MeasurementsAndProduct_20"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_20.dtype,
       gc_product_20.product_key,
       gc_product_20.product_name
FROM gc_measurement
         JOIN gc_product_measurement_20 ON gc_product_measurement_20.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_20 ON gc_product_measurement_20.product_key = gc_product_20.product_key;

alter table "MeasurementsAndProduct_20"
    owner to geocube;

