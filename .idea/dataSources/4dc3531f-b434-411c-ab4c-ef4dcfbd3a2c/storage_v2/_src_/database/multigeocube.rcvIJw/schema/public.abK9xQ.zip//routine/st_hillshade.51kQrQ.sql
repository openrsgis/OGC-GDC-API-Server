create function st_hillshade(rast raster, band integer, pixeltype text, azimuth double precision, altitude double precision, max_bright double precision DEFAULT 255.0, elevation_scale double precision DEFAULT 1.0) returns raster
    stable
    language sql
as
$$
SELECT st_mapalgebrafctngb($1, $2, $3, 1, 1, '_st_hillshade4ma(float[][], text, text[])'::regprocedure, 'value', st_pixelwidth($1)::text, st_pixelheight($1)::text, $4::text, $5::text, $6::text, $7::text)
$$;

comment on function st_hillshade(raster, integer, text, double precision, double precision, double precision, double precision) is 'args: rast, band, pixeltype, azimuth, altitude, max_bright=255, elevation_scale=1 - Returns the hypothetical illumination of an elevation raster band using provided azimuth, altitude, brightness and elevation scale inputs. Useful for visualizing terrain.';

alter function st_hillshade(raster, integer, text, double precision, double precision, double precision, double precision) owner to postgres;

