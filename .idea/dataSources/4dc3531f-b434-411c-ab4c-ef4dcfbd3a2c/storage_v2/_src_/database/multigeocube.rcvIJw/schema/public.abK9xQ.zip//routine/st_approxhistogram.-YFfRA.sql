create function st_approxhistogram(rast raster, nband integer, exclude_nodata_value boolean, sample_percent double precision, bins integer, "right" boolean) returns SETOF histogram
    immutable
    strict
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, $2, $3, $4, $5, NULL, $6)
$$;

alter function st_approxhistogram(raster, integer, boolean, double precision, integer, boolean) owner to postgres;

