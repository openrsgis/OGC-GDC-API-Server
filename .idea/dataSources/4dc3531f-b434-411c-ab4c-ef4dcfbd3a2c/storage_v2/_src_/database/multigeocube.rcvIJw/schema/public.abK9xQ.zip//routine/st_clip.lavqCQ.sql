create function st_clip(rast raster, band integer, geom geometry, nodataval double precision, crop boolean DEFAULT true) returns raster
    stable
    language sql
as
$$
SELECT ST_Clip($1, $2, $3, ARRAY[$4], $5)
$$;

alter function st_clip(raster, integer, geometry, double precision, boolean) owner to postgres;

