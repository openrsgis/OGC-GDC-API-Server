create view "LevelAndExtent_9"
            (extent_key, grid_code, city_code, province_name, district_name, extent, tile_size, cell_res, level) as
SELECT gc_extent_9.extent_key,
       gc_extent_9.grid_code,
       gc_extent_9.city_code,
       gc_extent_9.province_name,
       gc_extent_9.district_name,
       gc_extent_9.extent,
       gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level
FROM gc_extent_9
         JOIN gc_level ON gc_extent_9.resolution_key = gc_level.resolution_key;

alter table "LevelAndExtent_9"
    owner to geocube;

