create view "LevelAndExtent_10"
            (extent_key, grid_code, city_code, province_name, district_name, extent, tile_size, cell_res, level) as
SELECT gc_extent_10.extent_key,
       gc_extent_10.grid_code,
       gc_extent_10.city_code,
       gc_extent_10.province_name,
       gc_extent_10.district_name,
       gc_extent_10.extent,
       gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level
FROM gc_extent_10
         JOIN gc_level ON gc_extent_10.resolution_key = gc_level.resolution_key;

alter table "LevelAndExtent_10"
    owner to geocube;

