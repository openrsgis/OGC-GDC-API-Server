create function st_polygonfromtext(text, integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_PolyFromText($1, $2)
$$;

comment on function st_polygonfromtext(text, integer) is 'args: WKT, srid - Makes a Geometry from WKT with the given SRID. If SRID is not give, it defaults to -1.';

alter function st_polygonfromtext(text, integer) owner to postgres;

