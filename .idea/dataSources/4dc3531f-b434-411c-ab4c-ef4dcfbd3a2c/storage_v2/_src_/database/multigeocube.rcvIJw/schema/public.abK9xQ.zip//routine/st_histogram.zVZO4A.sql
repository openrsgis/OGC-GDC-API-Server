create function st_histogram(rast raster, nband integer, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false) returns SETOF histogram
    immutable
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, $2, TRUE, 1, $3, $4, $5)
$$;

comment on function st_histogram(raster, integer, integer, double precision[], boolean) is 'args: rast, nband, bins, width=NULL, right=false - Returns a set of histogram summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(raster, integer, integer, double precision[], boolean) owner to postgres;

