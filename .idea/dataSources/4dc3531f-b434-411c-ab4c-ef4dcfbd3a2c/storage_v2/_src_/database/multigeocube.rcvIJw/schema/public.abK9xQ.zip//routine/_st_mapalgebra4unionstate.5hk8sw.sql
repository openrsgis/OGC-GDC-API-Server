create function _st_mapalgebra4unionstate(rast1 raster, rast2 raster) returns raster
    language sql
as
$$
SELECT _ST_MapAlgebra4UnionState($1,$2, 'LAST', NULL, NULL, NULL, NULL, NULL, NULL, NULL)
$$;

alter function _st_mapalgebra4unionstate(raster, raster) owner to postgres;

