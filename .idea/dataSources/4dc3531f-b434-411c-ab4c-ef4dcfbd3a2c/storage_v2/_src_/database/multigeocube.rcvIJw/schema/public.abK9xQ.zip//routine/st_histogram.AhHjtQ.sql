create function st_histogram(rast raster, nband integer, bins integer, "right" boolean) returns SETOF histogram
    immutable
    strict
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, $2, TRUE, 1, $3, NULL, $4)
$$;

comment on function st_histogram(raster, integer, integer, boolean) is 'args: rast, nband, bins, right - Returns a set of histogram summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(raster, integer, integer, boolean) owner to postgres;

