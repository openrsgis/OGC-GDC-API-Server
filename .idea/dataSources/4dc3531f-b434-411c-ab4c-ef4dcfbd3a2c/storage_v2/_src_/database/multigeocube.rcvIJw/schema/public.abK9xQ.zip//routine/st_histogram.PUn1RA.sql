create function st_histogram(rastertable text, rastercolumn text, nband integer, exclude_nodata_value boolean, bins integer, "right" boolean) returns SETOF histogram
    stable
    strict
    language sql
as
$$
SELECT _st_histogram($1, $2, $3, $4, 1, $5, NULL, $6)
$$;

comment on function st_histogram(text, text, integer, boolean, integer, boolean) is 'args: rastertable, rastercolumn, nband, exclude_nodata_value, bins, right - Returns a set of histogram summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(text, text, integer, boolean, integer, boolean) owner to postgres;

