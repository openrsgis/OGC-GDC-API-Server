create view "MeasurementsAndProduct_11"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement_11.dtype,
       gc_product_11.product_key,
       gc_product_11.product_name
FROM gc_measurement
         JOIN gc_product_measurement_11 ON gc_product_measurement_11.measurement_key = gc_measurement.measurement_key
         JOIN gc_product_11 ON gc_product_measurement_11.product_key = gc_product_11.product_key;

alter table "MeasurementsAndProduct_11"
    owner to geocube;

