create function _add_raster_constraint_extent(rastschema name, rasttable name, rastcolumn name) returns boolean
    strict
    language plpgsql
as
$$
DECLARE
		fqtn text;
		cn name;
		sql text;
		attr text;
	BEGIN
		fqtn := '';
		IF length($1) > 0 THEN
			fqtn := quote_ident($1) || '.';
		END IF;
		fqtn := fqtn || quote_ident($2);

		cn := 'enforce_max_extent_' || $3;

		sql := 'SELECT st_ashexewkb(st_convexhull(st_collect(st_convexhull('
			|| quote_ident($3)
			|| ')))) FROM '
			|| fqtn;
		BEGIN
			EXECUTE sql INTO attr;
		EXCEPTION WHEN OTHERS THEN
			RAISE NOTICE 'Unable to get the extent of a sample raster. Attempting memory efficient (slower) approach';

			sql := 'SELECT st_ashexewkb(st_convexhull(st_memunion(st_convexhull('
				|| quote_ident($3)
				|| ')))) FROM '
				|| fqtn;
			BEGIN
				EXECUTE sql INTO attr;
			EXCEPTION WHEN OTHERS THEN
				RAISE NOTICE 'Still unable to get the extent of a sample raster. Cannot add extent constraint';
				RETURN FALSE;
			END;
		END;

		sql := 'ALTER TABLE ' || fqtn
			|| ' ADD CONSTRAINT ' || quote_ident(cn)
			|| ' CHECK (st_coveredby(st_convexhull('
			|| quote_ident($3)
			|| '), ''' || attr || '''::geometry))';
		RETURN _add_raster_constraint(cn, sql);
	END;

$$;

alter function _add_raster_constraint_extent(name, name, name) owner to postgres;

