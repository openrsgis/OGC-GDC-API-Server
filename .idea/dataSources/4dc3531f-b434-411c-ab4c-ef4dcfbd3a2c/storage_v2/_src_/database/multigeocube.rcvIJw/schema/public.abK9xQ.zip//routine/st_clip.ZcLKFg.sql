create function st_clip(rast raster, geom geometry, nodataval double precision[] DEFAULT NULL::double precision[], crop boolean DEFAULT true) returns raster
    stable
    language sql
as
$$
SELECT ST_Clip($1, NULL, $2, $3, $4)
$$;

comment on function st_clip(raster, geometry, double precision[], boolean) is 'args: rast, geom, nodataval=NULL, crop=true - Returns the raster clipped by the input geometry. If no band is specified all bands are returned. If crop is not specified, true is assumed meaning the output raster is cropped.';

alter function st_clip(raster, geometry, double precision[], boolean) owner to postgres;

