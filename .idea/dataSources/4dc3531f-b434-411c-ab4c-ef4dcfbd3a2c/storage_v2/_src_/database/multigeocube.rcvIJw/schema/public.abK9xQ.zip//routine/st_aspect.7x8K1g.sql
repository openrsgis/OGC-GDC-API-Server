create function st_aspect(rast raster, band integer, pixeltype text) returns raster
    stable
    language sql
as
$$
SELECT st_mapalgebrafctngb($1, $2, $3, 1, 1, '_st_aspect4ma(float[][], text, text[])'::regprocedure, 'value', st_pixelwidth($1)::text, st_pixelheight($1)::text)
$$;

comment on function st_aspect(raster, integer, text) is 'args: rast, band, pixeltype - Returns the surface aspect of an elevation raster band. Useful for analyzing terrain.';

alter function st_aspect(raster, integer, text) owner to postgres;

