create function box3dtobox(box3d) returns box
    immutable
    strict
    language sql
as
$$
SELECT box($1)
$$;

alter function box3dtobox(box3d) owner to postgres;

