create function st_approxquantile(rastertable text, rastercolumn text, sample_percent double precision, quantiles double precision[] DEFAULT NULL::double precision[]) returns SETOF quantile
    stable
    language sql
as
$$
SELECT _st_quantile($1, $2, 1, TRUE, $3, $4)
$$;

alter function st_approxquantile(text, text, double precision, double precision[]) owner to postgres;

