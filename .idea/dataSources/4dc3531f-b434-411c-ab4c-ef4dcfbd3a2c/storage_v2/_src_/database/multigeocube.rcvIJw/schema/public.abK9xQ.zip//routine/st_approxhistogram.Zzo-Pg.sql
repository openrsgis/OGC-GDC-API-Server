create function st_approxhistogram(rast raster, nband integer, sample_percent double precision) returns SETOF histogram
    immutable
    strict
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, $2, TRUE, $3, 0, NULL, FALSE)
$$;

alter function st_approxhistogram(raster, integer, double precision) owner to postgres;

