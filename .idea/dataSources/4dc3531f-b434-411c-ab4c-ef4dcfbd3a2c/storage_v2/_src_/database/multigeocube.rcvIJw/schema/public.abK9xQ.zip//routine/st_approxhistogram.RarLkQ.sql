create function st_approxhistogram(rastertable text, rastercolumn text, nband integer, sample_percent double precision, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false) returns SETOF histogram
    stable
    strict
    language sql
as
$$
SELECT _st_histogram($1, $2, $3, TRUE, $4, $5, $6, $7)
$$;

alter function st_approxhistogram(text, text, integer, double precision, integer, double precision[], boolean) owner to postgres;

