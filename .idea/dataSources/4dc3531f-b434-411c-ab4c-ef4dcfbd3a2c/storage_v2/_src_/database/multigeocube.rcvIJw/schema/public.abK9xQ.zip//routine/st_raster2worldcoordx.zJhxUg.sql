create function st_raster2worldcoordx(rast raster, xr integer) returns double precision
    immutable
    strict
    language sql
as
$$
SELECT longitude FROM _st_raster2worldcoord($1, $2, NULL)
$$;

comment on function st_raster2worldcoordx(raster, integer) is 'args: rast, xcolumn - Returns the geometric X coordinate upper left of a raster, column and row. Numbering of columns and rows starts at 1.';

alter function st_raster2worldcoordx(raster, integer) owner to postgres;

