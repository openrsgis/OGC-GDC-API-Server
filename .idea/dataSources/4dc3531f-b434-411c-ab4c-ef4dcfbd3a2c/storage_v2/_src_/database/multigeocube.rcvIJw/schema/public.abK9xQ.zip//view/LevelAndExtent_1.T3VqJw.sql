create view "LevelAndExtent_1"
            (extent_key, grid_code, city_code, city_name, province_name, district_name, extent, tile_size, cell_res,
             level) as
SELECT gc_extent_1.extent_key,
       gc_extent_1.grid_code,
       gc_extent_1.city_code,
       gc_extent_1.city_name,
       gc_extent_1.province_name,
       gc_extent_1.district_name,
       gc_extent_1.extent,
       gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level
FROM gc_extent_1
         JOIN gc_level ON gc_extent_1.resolution_key = gc_level.resolution_key;

alter table "LevelAndExtent_1"
    owner to geocube;

