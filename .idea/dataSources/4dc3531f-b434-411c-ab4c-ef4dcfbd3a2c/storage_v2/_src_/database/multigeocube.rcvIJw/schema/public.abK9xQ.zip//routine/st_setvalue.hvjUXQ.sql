create function st_setvalue(rast raster, pt geometry, newvalue double precision) returns raster
    language sql
as
$$
SELECT st_setvalue($1, 1, $2, $3)
$$;

comment on function st_setvalue(raster, geometry, double precision) is 'args: rast, pt, newvalue - Returns modified raster resulting from setting the value of a given band in a given columnx, rowy pixel or at a pixel that intersects a particular geometric point. Band numbers start at 1 and assumed to be 1 if not specified.';

alter function st_setvalue(raster, geometry, double precision) owner to postgres;

