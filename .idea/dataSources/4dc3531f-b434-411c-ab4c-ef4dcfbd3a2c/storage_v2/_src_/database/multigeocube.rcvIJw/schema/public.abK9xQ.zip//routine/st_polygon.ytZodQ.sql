create function st_polygon(rast raster, band integer DEFAULT 1) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT st_union(f.geom) AS singlegeom
    FROM (SELECT (st_dumpaspolygons($1, $2)).geom AS geom) AS f;
$$;

comment on function st_polygon(raster, integer) is 'args: rast, band_num=1 - Returns a polygon geometry formed by the union of pixels that have a pixel value that is not no data value. If no band number is specified, band num defaults to 1.';

alter function st_polygon(raster, integer) owner to postgres;

