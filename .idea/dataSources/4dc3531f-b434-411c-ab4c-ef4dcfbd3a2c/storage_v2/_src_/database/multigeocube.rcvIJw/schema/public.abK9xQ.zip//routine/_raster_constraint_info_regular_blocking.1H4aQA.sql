create function _raster_constraint_info_regular_blocking(rastschema name, rasttable name, rastcolumn name) returns boolean
    stable
    strict
    language plpgsql
as
$$
DECLARE
		cn text;
		sql text;
		rtn boolean;
	BEGIN
		cn := 'enforce_regular_blocking_' || $3;

		sql := 'SELECT TRUE FROM pg_class c, pg_namespace n, pg_constraint s'
			|| ' WHERE n.nspname = ' || quote_literal($1)
			|| ' AND c.relname = ' || quote_literal($2)
			|| ' AND s.connamespace = n.oid AND s.conrelid = c.oid'
			|| ' AND s.conname = ' || quote_literal(cn);
		EXECUTE sql INTO rtn;
		RETURN rtn;
	END;

$$;

alter function _raster_constraint_info_regular_blocking(name, name, name) owner to postgres;

