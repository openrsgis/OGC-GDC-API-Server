create function _st_mapalgebra4unionstate(rast1 raster, rast2 raster, p_expression text) returns raster
    language sql
as
$$
SELECT _ST_MapAlgebra4UnionState($1,$2, $3, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
$$;

alter function _st_mapalgebra4unionstate(raster, raster, text) owner to postgres;

