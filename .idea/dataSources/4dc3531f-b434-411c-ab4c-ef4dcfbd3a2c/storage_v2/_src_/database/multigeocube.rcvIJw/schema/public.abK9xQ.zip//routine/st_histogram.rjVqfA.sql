create function st_histogram(rastertable text, rastercolumn text, nband integer, bins integer, width double precision[] DEFAULT NULL::double precision[], "right" boolean DEFAULT false) returns SETOF histogram
    stable
    language sql
as
$$
SELECT _st_histogram($1, $2, $3, TRUE, 1, $4, $5, $6)
$$;

comment on function st_histogram(text, text, integer, integer, double precision[], boolean) is 'args: rastertable, rastercolumn, nband=1, bins, width=NULL, right=false - Returns a set of histogram summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(text, text, integer, integer, double precision[], boolean) owner to postgres;

