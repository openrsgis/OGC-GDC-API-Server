create function _st_hillshade4ma(matrix double precision[], nodatamode text, VARIADIC args text[]) returns double precision
    immutable
    language plpgsql
as
$$
DECLARE
        pwidth float;
        pheight float;
        dz_dx float;
        dz_dy float;
        zenith float;
        azimuth float;
        slope float;
        aspect float;
        max_bright float;
        elevation_scale float;
    BEGIN
        pwidth := args[1]::float;
        pheight := args[2]::float;
        azimuth := (5.0 * pi() / 2.0) - args[3]::float;
        zenith := (pi() / 2.0) - args[4]::float;
        dz_dx := ((matrix[3][1] + 2.0 * matrix[3][2] + matrix[3][3]) - (matrix[1][1] + 2.0 * matrix[1][2] + matrix[1][3])) / (8.0 * pwidth);
        dz_dy := ((matrix[1][3] + 2.0 * matrix[2][3] + matrix[3][3]) - (matrix[1][1] + 2.0 * matrix[2][1] + matrix[3][1])) / (8.0 * pheight);
        elevation_scale := args[6]::float;
        slope := atan(sqrt(elevation_scale * pow(dz_dx, 2.0) + pow(dz_dy, 2.0)));

        IF dz_dx != 0. THEN
            aspect := atan2(dz_dy, -dz_dx);
						IF aspect < 0 THEN
							aspect := aspect + (2.0 * pi());
						END IF;
				ELSE
					IF dz_dy > 0.THEN
						aspect := pi() / 2.;
					ELSEIF dz_dy < 0.THEN
						aspect := (2 * pi()) - (pi() / 2.);
					-- set to pi as that is the expected PostgreSQL answer in Linux
					ELSE
            aspect := pi();
        	END IF;
        END IF;
        max_bright := args[5]::float;

        RETURN max_bright * ( (cos(zenith)*cos(slope)) + (sin(zenith)*sin(slope)*cos(azimuth - aspect)) );
    END;
$$;

alter function _st_hillshade4ma(double precision[], text, text[]) owner to postgres;

