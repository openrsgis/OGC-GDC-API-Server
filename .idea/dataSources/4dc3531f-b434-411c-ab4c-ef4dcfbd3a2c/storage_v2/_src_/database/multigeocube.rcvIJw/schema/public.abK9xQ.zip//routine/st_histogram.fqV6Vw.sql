create function st_histogram(rast raster, nband integer, exclude_nodata_value boolean, bins integer, "right" boolean) returns SETOF histogram
    immutable
    strict
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, $2, $3, 1, $4, NULL, $5)
$$;

comment on function st_histogram(raster, integer, boolean, integer, boolean) is 'args: rast, nband, exclude_nodata_value, bins, right - Returns a set of histogram summarizing a raster or raster coverage data distribution separate bin ranges. Number of bins are autocomputed if not specified.';

alter function st_histogram(raster, integer, boolean, integer, boolean) owner to postgres;

