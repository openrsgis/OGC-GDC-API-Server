create function st_approxhistogram(rast raster, nband integer, sample_percent double precision, bins integer, "right" boolean) returns SETOF histogram
    immutable
    strict
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, $2, TRUE, $3, $4, NULL, $5)
$$;

alter function st_approxhistogram(raster, integer, double precision, integer, boolean) owner to postgres;

