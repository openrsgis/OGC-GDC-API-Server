create function st_approxhistogram(rast raster, sample_percent double precision) returns SETOF histogram
    immutable
    strict
    language sql
as
$$
SELECT min, max, count, percent FROM _st_histogram($1, 1, TRUE, $2, 0, NULL, FALSE)
$$;

alter function st_approxhistogram(raster, double precision) owner to postgres;

