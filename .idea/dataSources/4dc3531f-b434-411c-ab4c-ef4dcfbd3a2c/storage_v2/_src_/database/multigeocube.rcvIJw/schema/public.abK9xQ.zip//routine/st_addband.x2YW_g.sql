create function st_addband(torast raster, fromrasts raster[], fromband integer DEFAULT 1) returns raster
    language plpgsql
as
$$
DECLARE var_result raster := torast;
		var_num integer := array_upper(fromrasts,1);
		var_i integer := 1; 
	BEGIN 
		IF torast IS NULL AND var_num > 0 THEN
			var_result := ST_Band(fromrasts[1],fromband); 
			var_i := 2;
		END IF;
		WHILE var_i <= var_num LOOP
			var_result := ST_AddBand(var_result, fromrasts[var_i], 1);
			var_i := var_i + 1;
		END LOOP;
		
		RETURN var_result;
	END;
$$;

comment on function st_addband(raster, raster[], integer) is 'args: torast, fromrasts, fromband=1 - Returns a raster with the new band(s) of given type added with given initial value in the given index location. If no index is specified, the band is added to the end.';

alter function st_addband(raster, raster[], integer) owner to postgres;

