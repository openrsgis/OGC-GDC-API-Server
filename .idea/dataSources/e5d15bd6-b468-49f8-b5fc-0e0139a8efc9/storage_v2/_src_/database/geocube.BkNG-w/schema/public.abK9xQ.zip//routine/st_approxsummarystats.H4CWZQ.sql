create function st_approxsummarystats(rastertable text, rastercolumn text, sample_percent double precision, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision) returns record
    stable
    strict
    language sql
as
$$
SELECT _st_summarystats($1, $2, 1, TRUE, $3)
$$;

alter function st_approxsummarystats(text, text, double precision, out bigint, out double precision, out double precision, out double precision, out double precision, out double precision) owner to postgres;

