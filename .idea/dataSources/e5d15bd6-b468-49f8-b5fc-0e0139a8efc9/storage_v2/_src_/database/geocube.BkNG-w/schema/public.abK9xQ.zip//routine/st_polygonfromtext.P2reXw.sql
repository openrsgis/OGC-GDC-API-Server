create function st_polygonfromtext(text) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_PolyFromText($1)
$$;

comment on function st_polygonfromtext(text) is 'args: WKT - Makes a Geometry from WKT with the given SRID. If SRID is not give, it defaults to 0.';

alter function st_polygonfromtext(text) owner to postgres;

