create function st_touches(rast1 raster, rast2 raster) returns boolean
    immutable
    cost 1000
    language sql
as
$$
SELECT st_touches($1, NULL::integer, $2, NULL::integer)
$$;

comment on function st_touches(raster, raster) is 'args: rastA, rastB - Return true if raster rastA and rastB have at least one point in common but their interiors do not intersect.';

alter function st_touches(raster, raster) owner to postgres;

