create function postgis_raster_scripts_installed() returns text
    immutable
    language sql
as
$$
SELECT '2.1.2'::text || ' r' || 12389::text AS version
$$;

alter function postgis_raster_scripts_installed() owner to postgres;

