create function _st_within(rast1 raster, nband1 integer, rast2 raster, nband2 integer) returns boolean
    immutable
    cost 1000
    language sql
as
$$
SELECT _st_contains($3, $4, $1, $2)
$$;

alter function _st_within(raster, integer, raster, integer) owner to postgres;

