create function st_reclass(rast raster, reclassexpr text, pixeltype text) returns raster
    immutable
    strict
    language sql
as
$$
SELECT st_reclass($1, ROW(1, $2, $3, NULL))
$$;

alter function st_reclass(raster, text, text) owner to postgres;

