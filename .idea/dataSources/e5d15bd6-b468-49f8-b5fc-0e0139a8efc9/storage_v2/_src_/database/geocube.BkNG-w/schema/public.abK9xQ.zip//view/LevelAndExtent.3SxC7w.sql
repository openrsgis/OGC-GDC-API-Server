create view "LevelAndExtent"
            (extent_key, grid_code, city_code, city_name, province_name, district_name, extent, tile_size, cell_res,
             level) as
SELECT gc_extent.extent_key,
       gc_extent.grid_code,
       gc_extent.city_code,
       gc_extent.city_name,
       gc_extent.province_name,
       gc_extent.district_name,
       gc_extent.extent,
       gc_level.tile_size,
       gc_level.cell_res,
       gc_level.level
FROM gc_extent
         JOIN gc_level ON gc_extent.resolution_key = gc_level.resolution_key;

alter table "LevelAndExtent"
    owner to geocube;

