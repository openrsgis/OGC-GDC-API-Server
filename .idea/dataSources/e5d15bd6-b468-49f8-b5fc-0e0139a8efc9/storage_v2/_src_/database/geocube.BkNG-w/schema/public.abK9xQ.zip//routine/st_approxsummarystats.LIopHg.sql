create function st_approxsummarystats(rast raster, nband integer, sample_percent double precision, OUT count bigint, OUT sum double precision, OUT mean double precision, OUT stddev double precision, OUT min double precision, OUT max double precision) returns record
    immutable
    strict
    language sql
as
$$
SELECT _st_summarystats($1, $2, TRUE, $3)
$$;

alter function st_approxsummarystats(raster, integer, double precision, out bigint, out double precision, out double precision, out double precision, out double precision, out double precision) owner to postgres;

