create function raster_same(raster, raster) returns boolean
    immutable
    strict
    language sql
as
$$
select $1::geometry ~= $2::geometry
$$;

alter function raster_same(raster, raster) owner to postgres;

