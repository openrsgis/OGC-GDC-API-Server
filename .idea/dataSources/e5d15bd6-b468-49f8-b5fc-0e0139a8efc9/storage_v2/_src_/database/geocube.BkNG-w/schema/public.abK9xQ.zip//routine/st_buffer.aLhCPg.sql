create function st_buffer(geometry, double precision, integer) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT _ST_Buffer($1, $2,
		CAST('quad_segs='||CAST($3 AS text) as cstring))

$$;

comment on function st_buffer(geometry, double precision, integer) is 'args: g1, radius_of_buffer, num_seg_quarter_circle - (T) For geometry: Returns a geometry that represents all points whose distance from this Geometry is less than or equal to distance. Calculations are in the Spatial Reference System of this Geometry. For geography: Uses a planar transform wrapper. Introduced in 1.5 support for different end cap and mitre settings to control shape. buffer_style options: quad_segs=#,endcap=round|flat|square,join=round|mitre|bevel,mitre_limit=#.#';

alter function st_buffer(geometry, double precision, integer) owner to postgres;

