create function st_envelope(raster) returns geometry
    immutable
    strict
    language sql
as
$$
select st_envelope(st_convexhull($1))
$$;

alter function st_envelope(raster) owner to postgres;

