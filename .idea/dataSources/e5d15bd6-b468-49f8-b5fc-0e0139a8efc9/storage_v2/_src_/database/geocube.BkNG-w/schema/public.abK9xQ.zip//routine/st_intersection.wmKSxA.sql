create function st_intersection(text, text) returns geometry
    immutable
    strict
    language sql
as
$$
SELECT ST_Intersection($1::geometry, $2::geometry);
$$;

alter function st_intersection(text, text) owner to postgres;

