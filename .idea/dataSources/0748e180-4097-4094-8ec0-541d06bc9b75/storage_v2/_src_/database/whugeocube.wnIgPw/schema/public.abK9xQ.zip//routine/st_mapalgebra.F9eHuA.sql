create function st_mapalgebra(rast raster, pixeltype text, expression text, nodataval double precision DEFAULT NULL::double precision) returns raster
    stable
    language sql
as
$$
SELECT st_mapalgebra($1, 1, $2, $3, $4)
$$;

alter function st_mapalgebra(raster, text, text, double precision) owner to postgres;

