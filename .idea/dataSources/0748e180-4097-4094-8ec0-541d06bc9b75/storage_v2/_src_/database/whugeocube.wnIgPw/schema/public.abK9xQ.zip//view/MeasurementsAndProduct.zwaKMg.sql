create view "MeasurementsAndProduct"(measurement_key, measurement_name, dtype, product_key, product_name) as
SELECT gc_measurement.measurement_key,
       gc_measurement.measurement_name,
       gc_product_measurement.dtype,
       gc_product.product_key,
       gc_product.product_name
FROM gc_measurement
         JOIN gc_product_measurement ON gc_product_measurement.measurement_key = gc_measurement.measurement_key
         JOIN gc_product ON gc_product_measurement.product_key = gc_product.product_key;

alter table "MeasurementsAndProduct"
    owner to geocube;

